# Guessing Game

A game where you guess a randomly generated number between 1 and 100.

## Features
- Feedback for guesses that are too high or too low.
- Tracks the number of attempts.

## Usage
Run the program and guess the number based on feedback.